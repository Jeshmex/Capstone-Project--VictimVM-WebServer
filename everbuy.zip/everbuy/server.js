// EverBuy — minimal static server for local hosting.
// Serves the site on your machine and exposes it to your local network.
const express = require('express');
const os = require('os');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0'; // listen on all interfaces so other devices on the LAN can reach it

app.use(express.static(path.join(__dirname)));

// Serve index.html for any unmatched route (keeps deep links working).
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, HOST, () => {
  const addrs = [];
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === 'IPv4' && !net.internal) addrs.push(net.address);
    }
  }
  console.log('\n  \x1b[36mEverBuy\x1b[0m is running 🛒\n');
  console.log(`  Local:    http://localhost:${PORT}`);
  addrs.forEach(a => console.log(`  Network:  http://${a}:${PORT}`));
  console.log('\n  Other devices on the same Wi-Fi can use a Network URL above.');
  console.log('  Press Ctrl+C to stop.\n');
});
