# EverBuy 🛒

A demo **marketplace storefront** — browse by department, search products, build a
cart, and check out — built as a self-contained front end you can host on your own
machine and reach from other devices on your network.

> **Note:** EverBuy is a fictional project for learning/portfolio use. It is its own
> brand (not affiliated with Amazon or any real retailer), and **no real accounts or
> payments are collected** — checkout is a demo.

---

## Features

- **Three navigation bars** — promo bar, main utility bar (search + cart), and a
  department bar
- **Browse by category** across 8 departments
- **Search** by keyword, scoped to a category via the dropdown
- **Sort** by price or average rating
- **Product detail** popup
- **Cart** with quantity steppers, remove, live subtotal, and an item-count badge
- **Cart persistence** via `localStorage` (falls back to in-memory if unavailable)
- Fully **responsive**, keyboard-accessible, and **offline** (thumbnails are drawn
  locally — no external images, fonts, or scripts)

---

## Quick start

```bash
git clone <your-repo-url> everbuy
cd everbuy
```

Then run it with **either** option below.

### Option A — Node (recommended)

Prints a local URL *and* your network URL so other devices can connect.

```bash
npm install     # one time: installs Express
npm start
```

Open the URL it prints (default **http://localhost:3000**).
Set a different port with `PORT=4000 npm start`.

### Option B — Python (no install)

Python 3 ships on most systems, so this needs nothing extra:

```bash
npm run serve:python
# or directly:
python3 -m http.server 8000 --bind 0.0.0.0
```

Open **http://localhost:8000**.

---

## Access it from other devices on your network

1. Make sure every device is on the **same Wi-Fi / LAN**.
2. Find this machine's local IP address:
   - **macOS:** `ipconfig getifaddr en0`
   - **Linux:** `hostname -I`
   - **Windows:** `ipconfig` → look at the *IPv4 Address*
3. On the other device, open `http://THAT-IP:PORT`
   (e.g. `http://192.168.1.24:3000`).

> The Node server already listens on all interfaces (`0.0.0.0`), so the network URL
> works out of the box. With the Python command, keep the `--bind 0.0.0.0` flag.

---

## Project structure

```
everbuy/
├── index.html          # markup for the storefront
├── assets/
│   ├── styles.css      # all styling
│   └── app.js          # products data + search / cart / UI logic
├── server.js           # tiny Express static server (prints local + network URLs)
├── package.json
├── .gitignore
├── LICENSE
└── README.md
```

To change the catalog, edit the `PRODUCTS` array near the top of `assets/app.js`.

---

## Troubleshooting

- **Other devices can't connect** → almost always the host **firewall**. Allow
  inbound TCP on your port (3000 or 8000). On Windows you'll usually get a prompt the
  first time; allow it for *Private* networks.
- **`Error: listen EADDRINUSE`** → the port is taken. Use another:
  `PORT=4000 npm start`.
- **`express` not found** → run `npm install` first (Option A).

---

## License

MIT — see [LICENSE](LICENSE).
