/* ============================ DATA ============================ */
const CATS = ["Electronics","Home & Kitchen","Books","Toys & Games","Fashion","Sports & Outdoors","Beauty","Grocery"];
const CAT_COLOR = {
  "Electronics":["#e3f0ff","#b9d9ff"], "Home & Kitchen":["#fdeede","#f7d9b0"],
  "Books":["#e7f6ec","#c3e9cf"], "Toys & Games":["#fde7f1","#f7c4dd"],
  "Fashion":["#eeeafe","#d4c9f7"], "Sports & Outdoors":["#e2f6f3","#bce9e1"],
  "Beauty":["#fdeef3","#f6cfe0"], "Grocery":["#f2f6e2","#dbe7b4"]
};
const P = (id,title,category,price,oldPrice,rating,reviews,emoji,desc)=>({id,title,category,price,oldPrice,rating,reviews,emoji,desc});
const PRODUCTS = [
  P(1,"Wireless Noise-Cancelling Earbuds","Electronics",79.99,129.99,4.6,8421,"🎧","40-hour battery, active noise cancellation, and a snug all-day fit."),
  P(2,"4K Action Camera with Stabilization","Electronics",149.00,199.00,4.4,2203,"📷","Waterproof to 10m, 4K/60fps, and buttery electronic stabilization."),
  P(3,"Compact Mechanical Keyboard","Electronics",64.50,null,4.7,5590,"⌨️","Hot-swappable switches, per-key backlight, wired or Bluetooth."),
  P(4,"Fitness Smartwatch","Electronics",119.99,159.99,4.3,11240,"⌚","Heart rate, sleep tracking, GPS, and a 7-day battery."),
  P(5,"Portable Bluetooth Speaker","Electronics",45.00,null,4.5,6712,"🔊","Punchy 360° sound, IPX7 waterproof, 24-hour playtime."),
  P(6,"1TB Portable SSD","Electronics",94.99,139.99,4.8,3301,"💾","Pocket-sized, 1050MB/s reads, shock-resistant enclosure."),
  P(7,"15-Bar Espresso Machine","Home & Kitchen",189.00,249.00,4.5,1870,"☕","Café-grade pressure, steam wand, and a quick 25-second heat-up."),
  P(8,"6-Quart Air Fryer","Home & Kitchen",89.99,119.99,4.6,22104,"🍟","Crisps with little to no oil; 8 presets and a dishwasher-safe basket."),
  P(9,"Robot Vacuum with Mapping","Home & Kitchen",229.00,329.00,4.2,4455,"🤖","Lidar mapping, app control, and automatic recharge-and-resume."),
  P(10,"8-Inch Chef's Knife","Home & Kitchen",39.95,null,4.7,9980,"🔪","High-carbon steel, full tang, hand-polished edge."),
  P(11,"Cast Iron Skillet","Home & Kitchen",27.50,null,4.8,15320,"🍳","Pre-seasoned, oven-safe to 500°F, lasts a lifetime."),
  P(12,"The Pragmatic Programmer","Books",41.99,49.99,4.8,7120,"📘","The classic guide to pragmatic software craftsmanship."),
  P(13,"Atomic Habits","Books",16.20,27.00,4.9,61200,"📗","An easy, proven way to build good habits and break bad ones."),
  P(14,"Dune (Deluxe Edition)","Books",22.00,null,4.7,33190,"📙","Frank Herbert's sweeping sci-fi epic, collector's hardcover."),
  P(15,"The Weeknight Cookbook","Books",19.99,32.00,4.5,2890,"📕","120 fast recipes for real dinners on real schedules."),
  P(16,"500-Piece Building Blocks","Toys & Games",34.99,null,4.6,4120,"🧱","Open-ended creative set, compatible with major brick brands."),
  P(17,"Strategy Board Game","Toys & Games",44.95,59.95,4.7,8810,"🎲","2–5 players, 60-minute games, endless replayability."),
  P(18,"Remote Control Rally Car","Toys & Games",52.00,null,4.3,1560,"🚗","4WD, 25mph, all-terrain tires and a 2-battery pack."),
  P(19,"Weighted Plush Bear","Toys & Games",24.99,null,4.8,6730,"🧸","Soft, calming, and machine-washable — a bedtime favorite."),
  P(20,"Everyday Running Sneakers","Fashion",68.00,95.00,4.4,12050,"👟","Responsive foam, breathable knit, go-anywhere look."),
  P(21,"Slim Leather Wallet (RFID)","Fashion",29.99,null,4.6,18900,"👛","Full-grain leather, RFID blocking, holds 8 cards."),
  P(22,"Polarized Sunglasses","Fashion",21.50,39.99,4.3,5540,"🕶️","UV400 polarized lenses, lightweight frame, hard case included."),
  P(23,"Everyday Commuter Backpack","Fashion",54.00,null,4.7,7420,"🎒","Padded 16\" laptop sleeve, water-resistant, USB pass-through."),
  P(24,"Non-Slip Yoga Mat","Sports & Outdoors",32.99,45.00,4.6,9330,"🧘","6mm cushioning, textured grip, carry strap included."),
  P(25,"Adjustable Dumbbell Set","Sports & Outdoors",179.00,249.00,4.7,3210,"🏋️","5–52.5 lb per hand, dial to change weight in seconds."),
  P(26,"2-Person Camping Tent","Sports & Outdoors",79.99,109.99,4.4,2680,"⛺","Waterproof, 60-second setup, packs down small."),
  P(27,"Insulated Water Bottle 32oz","Sports & Outdoors",24.00,null,4.8,41200,"🧴","Cold 24h / hot 12h, leak-proof, fits most cup holders."),
  P(28,"5-Step Skincare Set","Beauty",48.00,65.00,4.5,3960,"🧴","Gentle, fragrance-free routine for all skin types."),
  P(29,"Ionic Hair Dryer","Beauty",59.99,null,4.4,7110,"💨","Fast-dry ionic tech, 3 heat settings, cool shot."),
  P(30,"Single-Origin Coffee Beans 2lb","Grocery",23.50,null,4.7,8820,"☕","Medium roast, notes of cocoa and caramel, freshly roasted."),
  P(31,"Dark Chocolate Bars (12-pack)","Grocery",18.99,25.00,4.6,5410,"🍫","72% cacao, ethically sourced, individually wrapped."),
  P(32,"Extra-Virgin Olive Oil 1L","Grocery",16.75,null,4.8,13020,"🫒","Cold-pressed, single-estate, peppery finish.")
];

/* ============================ STATE ============================ */
const memory = {};
const store = {
  get(k){ try{ return localStorage.getItem(k); }catch(e){ return k in memory ? memory[k] : null; } },
  set(k,v){ try{ localStorage.setItem(k,v); }catch(e){ memory[k]=v; } }
};
let state = { cat:"All", q:"", sort:"featured", deals:false };
let cart = {};
try{ cart = JSON.parse(store.get("everbuy_cart")||"{}") || {}; }catch(e){ cart = {}; }

const money = n => "$"+n.toFixed(2);
const grad = c => `linear-gradient(135deg,${CAT_COLOR[c][0]},${CAT_COLOR[c][1]})`;
const stars = r => {const f=Math.round(r);return "★★★★★".slice(0,f)+"☆☆☆☆☆".slice(0,5-f);};

/* ============================ BUILD NAV ============================ */
const searchCat = document.getElementById('searchCat');
searchCat.innerHTML = `<option value="All">All</option>` + CATS.map(c=>`<option value="${c}">${c}</option>`).join('');

const deptBar = document.getElementById('deptBar');
deptBar.insertAdjacentHTML('beforeend',
  `<button data-cat="Deals">Today's Deals</button>` +
  CATS.map(c=>`<button data-cat="${c}">${c}</button>`).join('')
);

/* ============================ RENDER GRID ============================ */
const grid = document.getElementById('grid');
const resultTitle = document.getElementById('resultTitle');
const resultCount = document.getElementById('resultCount');

function currentList(){
  let list = PRODUCTS.slice();
  if(state.deals) list = list.filter(p=>p.oldPrice);
  if(state.cat!=="All") list = list.filter(p=>p.category===state.cat);
  if(state.q){
    const q = state.q.toLowerCase();
    list = list.filter(p=>p.title.toLowerCase().includes(q)||p.category.toLowerCase().includes(q)||p.desc.toLowerCase().includes(q));
  }
  switch(state.sort){
    case "price-asc": list.sort((a,b)=>a.price-b.price); break;
    case "price-desc": list.sort((a,b)=>b.price-a.price); break;
    case "rating": list.sort((a,b)=>b.rating-a.rating); break;
  }
  return list;
}

function render(){
  const list = currentList();
  let title = state.deals ? "Today's Deals" : (state.cat==="All" ? "All products" : state.cat);
  if(state.q) title = `Results for “${state.q}”`;
  resultTitle.childNodes[0].nodeValue = title + " ";
  resultCount.textContent = `(${list.length} item${list.length!==1?'s':''})`;

  // sync department highlighting
  deptBar.querySelectorAll('button').forEach(b=>{
    const c=b.dataset.cat;
    b.classList.toggle('active',(c==="Deals"&&state.deals)||(!state.deals&&c===state.cat));
  });

  if(!list.length){
    grid.innerHTML = `<div class="empty"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg><p>No products match your search.<br>Try another term or category.</p></div>`;
    return;
  }
  grid.innerHTML = list.map(p=>{
    const inCart = cart[p.id] ? ' in' : '';
    const label = cart[p.id] ? `In cart (${cart[p.id]})` : 'Add to cart';
    const disc = p.oldPrice ? Math.round((1-p.price/p.oldPrice)*100) : 0;
    const [dollars,cents] = p.price.toFixed(2).split('.');
    return `<article class="card" data-id="${p.id}">
      <div class="thumb" style="background:${grad(p.category)}" data-open="${p.id}">
        ${p.oldPrice?`<span class="deal-badge">-${disc}%</span>`:''}${p.emoji}
      </div>
      <h3 data-open="${p.id}">${p.title}</h3>
      <div class="rating"><span class="stars" aria-label="${p.rating} out of 5">${stars(p.rating)}</span><span>${p.rating} · ${p.reviews.toLocaleString()}</span></div>
      <div class="price">
        <span class="now">$${dollars}<span class="cents">${cents}</span></span>
        ${p.oldPrice?`<span class="was">${money(p.oldPrice)}</span>`:''}
      </div>
      <div class="ship"><b>FREE delivery</b> ${p.price>=35?'':'with $35+ order'}</div>
      <button class="add${inCart}" data-add="${p.id}">${label}</button>
    </article>`;
  }).join('');
}

/* ============================ CART ============================ */
const cartCount = document.getElementById('cartCount');
const ditems = document.getElementById('ditems');
const subtotalEl = document.getElementById('subtotal');
const checkoutBtn = document.getElementById('checkout');
const drawerTitle = document.getElementById('drawerTitle');
const byId = id => PRODUCTS.find(p=>p.id===id);

function saveCart(){ store.set("everbuy_cart", JSON.stringify(cart)); }
function cartQty(){ return Object.values(cart).reduce((a,b)=>a+b,0); }
function cartTotal(){ return Object.entries(cart).reduce((s,[id,q])=>s+byId(+id).price*q,0); }

function updateCartUI(){
  const n = cartQty();
  cartCount.textContent = n;
  drawerTitle.textContent = `Your Cart (${n})`;
  subtotalEl.textContent = money(cartTotal());
  checkoutBtn.disabled = n===0;

  const ids = Object.keys(cart);
  if(!ids.length){
    ditems.innerHTML = `<div class="dcart-empty">Your cart is empty.<br>Start adding products to see them here.</div>`;
    return;
  }
  ditems.innerHTML = ids.map(id=>{
    const p = byId(+id), q = cart[id];
    return `<div class="ditem">
      <div class="dt" style="background:${grad(p.category)}">${p.emoji}</div>
      <div class="dinfo">
        <div class="dname">${p.title}</div>
        <div class="dprice">${money(p.price)}</div>
        <div>
          <span class="qty">
            <button data-dec="${id}" aria-label="Decrease quantity">−</button>
            <span>${q}</span>
            <button data-inc="${id}" aria-label="Increase quantity">+</button>
          </span>
          <button class="remove" data-rm="${id}">Remove</button>
        </div>
      </div>
    </div>`;
  }).join('');
}

function addToCart(id){ cart[id]=(cart[id]||0)+1; saveCart(); updateCartUI(); render(); showToast(`Added: ${byId(id).title}`); }
function setQty(id,delta){ cart[id]=(cart[id]||0)+delta; if(cart[id]<=0) delete cart[id]; saveCart(); updateCartUI(); render(); }
function removeItem(id){ delete cart[id]; saveCart(); updateCartUI(); render(); }

/* ============================ DRAWER / MODAL / TOAST ============================ */
const overlay=document.getElementById('overlay'), drawer=document.getElementById('drawer');
function openCart(){ overlay.classList.add('open'); drawer.classList.add('open'); drawer.setAttribute('aria-hidden','false'); }
function closeCart(){ overlay.classList.remove('open'); drawer.classList.remove('open'); drawer.setAttribute('aria-hidden','true'); }

const modalBd=document.getElementById('modalBd'), modal=document.getElementById('modal');
function openModal(id){
  const p=byId(id); const [d,c]=p.price.toFixed(2).split('.');
  modal.innerHTML=`<div class="m-img" style="background:${grad(p.category)}">${p.emoji}</div>
    <div class="m-body">
      <span class="m-cat">${p.category}</span>
      <h2>${p.title}</h2>
      <div class="rating"><span class="stars">${stars(p.rating)}</span><span>${p.rating} · ${p.reviews.toLocaleString()} ratings</span></div>
      <div class="price" style="margin-top:12px"><span class="now">$${d}<span class="cents">${c}</span></span>${p.oldPrice?`<span class="was">${money(p.oldPrice)}</span>`:''}</div>
      <div class="ship" style="margin-top:4px"><b>FREE delivery</b> on this item</div>
      <p class="m-desc">${p.desc}</p>
      <button class="add" style="max-width:220px" data-add="${p.id}">${cart[p.id]?`In cart (${cart[p.id]})`:'Add to cart'}</button>
    </div>`;
  modalBd.classList.add('open');
}
function closeModal(){ modalBd.classList.remove('open'); }

const toast=document.getElementById('toast'), toastMsg=document.getElementById('toastMsg');
let toastT;
function showToast(msg){ toastMsg.textContent=msg; toast.classList.add('show'); clearTimeout(toastT); toastT=setTimeout(()=>toast.classList.remove('show'),1900); }

/* ============================ EVENTS ============================ */
document.getElementById('cartOpen').addEventListener('click',openCart);
document.getElementById('cartClose').addEventListener('click',closeCart);
overlay.addEventListener('click',closeCart);
document.getElementById('modalClose').addEventListener('click',closeModal);
modalBd.addEventListener('click',e=>{ if(e.target===modalBd) closeModal(); });
document.addEventListener('keydown',e=>{ if(e.key==='Escape'){ closeCart(); closeModal(); } });

// grid: add to cart + open modal (event delegation)
grid.addEventListener('click',e=>{
  const add=e.target.closest('[data-add]'); if(add){ addToCart(+add.dataset.add); return; }
  const open=e.target.closest('[data-open]'); if(open){ openModal(+open.dataset.open); }
});
// modal add-to-cart
modal.addEventListener('click',e=>{
  const add=e.target.closest('[data-add]');
  if(add){ addToCart(+add.dataset.add); add.textContent=`In cart (${cart[+add.dataset.add]})`; add.classList.add('in'); }
});
// cart qty / remove
ditems.addEventListener('click',e=>{
  const inc=e.target.closest('[data-inc]'); if(inc) return setQty(+inc.dataset.inc,1);
  const dec=e.target.closest('[data-dec]'); if(dec) return setQty(+dec.dataset.dec,-1);
  const rm=e.target.closest('[data-rm]'); if(rm) return removeItem(+rm.dataset.rm);
});
checkoutBtn.addEventListener('click',()=>{
  showToast(`Demo checkout — ${cartQty()} item(s), ${money(cartTotal())}. No real payment taken.`);
});

// department bar
deptBar.addEventListener('click',e=>{
  const b=e.target.closest('button[data-cat]'); if(!b) return;
  const c=b.dataset.cat;
  state.q=''; document.getElementById('searchInput').value='';
  if(c==="Deals"){ state.deals=true; state.cat="All"; }
  else { state.deals=false; state.cat=c; searchCat.value=(c==="All"?"All":c); }
  render(); window.scrollTo({top:0,behavior:'smooth'});
});
document.getElementById('shopDeals').addEventListener('click',()=>{ state.deals=true; state.cat="All"; state.q=''; render(); });

// footer category links
document.querySelectorAll('.foot-cat').forEach(a=>a.addEventListener('click',e=>{
  e.preventDefault(); state.deals=false; state.q=''; state.cat=a.textContent; searchCat.value=a.textContent; render();
  window.scrollTo({top:0,behavior:'smooth'});
}));

// search
const searchInput=document.getElementById('searchInput');
document.getElementById('searchForm').addEventListener('submit',e=>{ e.preventDefault(); applySearch(); });
searchInput.addEventListener('input',applySearch);
searchCat.addEventListener('change',()=>{ state.cat=searchCat.value; state.deals=false; render(); });
function applySearch(){ state.q=searchInput.value.trim(); state.deals=false; state.cat=searchCat.value; render(); }

// sort
document.getElementById('sortBy').addEventListener('change',e=>{ state.sort=e.target.value; render(); });

// back to top
document.getElementById('backTop').addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));

/* ============================ INIT ============================ */
updateCartUI();
render();
